<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Nilai Mahasiswa</title>
    <link rel="stylesheet" type="text/css "href="css/bootstrap.min.css">
</head>

<body >
  <div class="container">
    <form class="" method="POST" action="form_nilai.php">
        
  <!-- Text input-->
  <div class="card mt-3">
  <div class="card-header bg-primary text-white">
      Form Nilai Siswa</div>

<div class="card-body ">
  <div class="form-group">
  <label>Nama Lengkap</label>
  <input type="text" name="nama" class="form-control" placeholder="Input Nama anda">
  </div>

  <div class="form-group">
  <label>NIM</label>
  <input type="number" name="nim" class="form-control" placeholder="Input Nilai UAS">
  </div>

  <div class="form-group">
  <label class="" for="selectbasic">Mata Kuliah</label>
  <div class="col-md-15">
    <select id="" name="matkul" class="form-control">
      <option value="Basis Data">Basis Data</option>
      <option value="Pemrograman Web">Pemrograman Web</option>
      <option value="PPKN">PPKN</option>
    </select>
  </div>

  <div class="form-group">
  <label>Nilai UTS</label>
  <input type="number" name="uts" class="form-control" placeholder="Input Nilai UTS ">
  </div>

  <div class="form-group">
  <label>Nilai UAS</label>
  <input type="number" name="uas" class="form-control" placeholder="Input Nilai UAS">
  </div>

  <div class="form-group">
  <label>Nilai Tugas/Praktikum</label>
  <input type="number" name="praktikum" class="form-control" placeholder="Input Nilai Praktikum">
  </div>

    <!-- Button -->
      <div class="form-group">
        
            <button type="submit" id="" name="proses" value="simpan" class="btn btn-primary">Simpan</button>
             <button type="reset" id="" name="hapus" class="btn btn-danger">Hapus</button>
 </div>
    </form>

 <?php
                    $proses = $_POST['proses'];
                    $nama = $_POST['nama'];
                    $nim = $_POST['nim'];
                    $matkul = $_POST['matkul'];
                    $uts = $_POST['uts'];
                    $uas = $_POST['uas'];
                    $tugas = $_POST['praktikum'];

                    $ns1 = ['id' => 1, 'nama' => 'Fatimah', 'nim' => '01111', 'matkul' => 'WEB', 'uts' => 85, 'uas' => 80, 'praktikum' => 78];
                    $ns2 = ['id' => 2, 'nama' => 'Aisyah', 'nim' => '01120', 'matkul' => 'DDP', 'uts' => 75, 'uas' => 80, 'praktikum' => 70];
                    $ns3 = ['id' => 3, 'nama' => 'Ali', 'nim' => '01193', 'matkul' => 'BDI', 'uts' => 70, 'uas' => 80, 'praktikum' => 75];
                    $ns4 = ['id' => 4, 'nama' => 'Fatih', 'nim' => '01214', 'matkul' => 'DDP', 'uts' => 90, 'uas' => 95, 'praktikum' => 85];

                    $ar_nilai = [$ns1, $ns2, $ns3, $ns4];
                    if (isset($_POST['proses'])) {
                        $ns5 = ['id' => 5, 'nama' => $_POST['nama'], 'nim' => $_POST['nim'], 'matkul' => $_POST['matkul'], 'uts' => $_POST['uts'], 'uas' => $_POST['uas'], 'praktikum' => $_POST['praktikum']];

                        array_push($ar_nilai, $ns5);
                    }
                    ?>
    </div>
  </div>
</div>

<div class="card mt-3 mb-3">
<div class="card-header bg-success text-white">
  Daftar Nilai Siswa
</div>

<div class="card-body ">
 <table class="table table-bordered table-striped ">
 <thead class="text-center">
   <tr >
     <th>No.</th>
     <th>Nama</th>
     <th>NIM</th>
     <th>Mata Kuliah</th>
     <th>Nilai UTS</th>
     <th>Nilai UAS</th>
     <th>Nilai Praktikum</th>
     <th>Nilai Akhir</th>
  </tr>
  </thead>
  <tbody>
      <?php
                    $nomor = 1;
                    foreach ($ar_nilai as $ns) {
                        echo '<tr class="text-center"> <td>' . $nomor . '</td>';
                        echo '<td class="text-left">' . $ns['nama'] . '</td>';
                        echo '<td>' . $ns['nim'] . '</td>';
                        echo '<td>' . $ns['matkul'] . '</td>';
                        echo '<td>' . $ns['uts'] . '</td>';
                        echo '<td>' . $ns['uas'] . '</td>';
                        echo '<td>' . $ns['praktikum'] . '</td>';

                        $nilai_akhir = ($ns['uts'] + $ns['uas'] + $ns['praktikum']) / 3;
                        echo '<td>' . number_format($nilai_akhir, 2, ',', '.') . '</td>';
                        echo '</tr>';
                        $nomor++;
                    }
                    ?>
  </tbody>
 </table>


<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>

</html>

